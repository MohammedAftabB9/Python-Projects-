sum=0
for i in range (0,6):
	a=int(input())
	sum+=a
print(sum/6)
